hoydeAar0 = 50
hoydeAar1 = 76
hoydeAar2 = 87
hoydeAar3 = 96

alder = int(input("Hvilken alder vil du vite hoyden for (0,1,2 eller 3 aar)? "))

if alder==0:
    print(hoydeAar0)
elif alder==1:
    print(hoydeAar1)
elif alder==2:
    print(hoydeAar2)
elif alder==3:
    print(hoydeAar3)
