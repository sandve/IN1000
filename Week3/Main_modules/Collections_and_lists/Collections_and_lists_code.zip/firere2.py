kast = []
kast.append(int(input("Kast 1: ")))
kast.append(int(input("Kast 2: ")))
kast.append(int(input("Kast 3: ")))
kast.append(int(input("Kast 4: ")))
kast.append(int(input("Kast 5: ")))

antall = kast.count(4)
poeng = antall * 4
print(poeng)
