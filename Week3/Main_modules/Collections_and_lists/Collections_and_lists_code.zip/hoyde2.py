hoydeAar = [50,76,87,96]
alder = int(input("Hvilken alder vil du vite hoyden for (0,1,2 eller 3 aar)? "))
print(hoydeAar[alder])
