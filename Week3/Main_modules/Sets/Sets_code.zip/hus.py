kast = [3,3,4,3,3]
ulike = set(kast)
antall = kast.count(kast[0])
print( len(ulike)==2 and antall in [2,3])
