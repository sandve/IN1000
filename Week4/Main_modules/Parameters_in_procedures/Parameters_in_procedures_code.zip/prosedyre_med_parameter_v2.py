def skrivAlder(alder):
    if alder > 6:
        print("Velkommen til mitt program");
    else:
        print("Gå heller ut og lek i skogen");

innlest = int(input("Hvor gammel er du? "))
skrivAlder(innlest)

innlest = int(input("Hvor gammel er du? "))
skrivAlder(innlest)

innlest = int(input("Hvor gammel er du? "))
skrivAlder(innlest)
