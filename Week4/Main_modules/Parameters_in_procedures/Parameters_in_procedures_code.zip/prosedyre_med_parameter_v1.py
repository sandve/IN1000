alder = int(input("Hvor gammel er du? "))
if alder > 6:
    print("Velkommen til mitt program");
else:
    print("Gå heller ut og lek i skogen");

alder = int(input("Hvor gammel er du? "))
if alder > 6:
    print("Velkommen til mitt program");
else:
    print("Gå heller ut og lek i skogen");

alder = int(input("Hvor gammel er du? "))
if alder > 6:
    print("Velkommen til mitt program");
else:
    print("Gå heller ut og lek i skogen");
