nytt_ord = input("Skriv inn ord! ")
print("***")
svar = input("Hva var ordet? ")
if svar == nytt_ord:
    print("Riktig")
else:
    print("Galt")
