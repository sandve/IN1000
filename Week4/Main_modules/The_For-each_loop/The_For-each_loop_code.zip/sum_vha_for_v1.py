summen = 0
for tall in [2,3,4]:
    summen += tall
print(summen)
