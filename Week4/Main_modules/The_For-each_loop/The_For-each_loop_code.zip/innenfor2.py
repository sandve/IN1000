tallene = [12, 16, 5, 16]
innenfor = True
for tall in tallene:
    if tall<=10 or tall>=20:
        innenfor = False
assert innenfor==False
