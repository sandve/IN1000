summen = 0
for tall in range(101):
    summen += tall
print(summen)
