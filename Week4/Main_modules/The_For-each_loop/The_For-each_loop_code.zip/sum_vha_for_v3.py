print(sum(range(101)))
