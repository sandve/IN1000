alder=0
while alder!=-1:
    alder = int(input("Hvor gammel er du? "))

    if alder > 6:
        print("Velkommen til mitt program");
    elif alder >= 0:
        print("Gaa heller ut og lek i skogen");
