def skriv_velkomst():
    innlest = input("Hvor gammel er du? ")
    alder = int(innlest)

    if alder > 6:
        print("Velkommen til mitt program");
    else:
        print("Gaa heller ut og lek i skogen");

skriv_velkomst()
skriv_velkomst()
skriv_velkomst()
