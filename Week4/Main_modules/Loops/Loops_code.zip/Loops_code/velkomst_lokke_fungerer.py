alder = int(input("Hvor gammel er du? "))
while alder!=-1:
    if alder > 6:
        print("Velkommen til mitt program")
    else:
        print("Gaa heller ut og lek i skogen")
    alder = int(input("Hvor gammel er du? "))
