summen = 0
tall = 1

while tall<=100:
  summen+=tall
  tall +=1

print(summen)
