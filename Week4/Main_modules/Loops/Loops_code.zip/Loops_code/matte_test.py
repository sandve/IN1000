tall = int(input("Hva er 4+7?"))

while (tall != 11):
    tall = int(input("Prov igjen!"))
