innlest = input("Skriv et tall ")
tall = int(innlest)
print("Det doble er:" )
print(tall*2)
