def velkomst(navn):
    print("Hei " + gk)

gk = "Geir Kjetil"
velkomst("tomt")
