def velkomst(navn):
    print("Hei " + navn)

def hovedprogram():
    gk = "Geir Kjetil"
    sa = "Siri Annethe"
    velkomst(gk)
    velkomst(sa)

hovedprogram()
