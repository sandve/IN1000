def velkomst(navn):
    print("Hei " + navn) 

gk = "Geir Kjetil"
sa = "Siri Annethe"

velkomst(gk)
velkomst(sa)
