def velkomst():
    print("Hei " + gk) #Fungerer, men fraraades!!

gk = "Geir Kjetil"
velkomst()
