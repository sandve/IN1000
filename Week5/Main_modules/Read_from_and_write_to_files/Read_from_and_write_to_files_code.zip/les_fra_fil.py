min_fil=open("mittFilNavn.txt")
for linje in min_fil:
    print("Her fant jeg: " + linje)
