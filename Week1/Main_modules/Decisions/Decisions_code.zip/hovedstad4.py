land = input("Velg land")
if land == "Norge":
    print("Oslo")
else:
    print("Kunne ikke brydd meg mindre!")
