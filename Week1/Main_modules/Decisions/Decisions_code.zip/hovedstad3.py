land = input("Velg land")
if land == "Norge":
    print("Oslo")
if land != "Norge":
    print("Kunne ikke brydd meg mindre!")
