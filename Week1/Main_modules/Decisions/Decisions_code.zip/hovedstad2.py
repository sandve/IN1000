land = input("Velg land i nordre Skandinavia: ")
if land == "Norge":
    print("Oslo")
    print("Kjent som byen ved fjorden")
if land == "Sverige":
    print("Stockholm")
    print("Kjent som byen ved elven")
print("Velkommen igjen")
