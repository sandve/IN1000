land = input("Velg land i nordre Skandinavia: ")
if land == "Norge":
    print("Oslo")
elif land == "Sverige":
    print("Stockholm")
elif land == "Danmark":
    print("Kobenhavn")
else:
    print("Ukjent land")
