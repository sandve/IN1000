alder =4 #fyll inn..

if alder>0:
    print("Velkommen til bhg")
    if alder<3:
        print("Du er smaabarn")
    else:
        print("Du er storbarn")
