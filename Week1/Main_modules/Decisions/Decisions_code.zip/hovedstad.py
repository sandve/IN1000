land = input("Velg land i nordre Skandinavia: ")
if land == "Norge":
    print("Oslo")
elif land == "Sverige":
    print("Stockholm")
else:
    print("Ukjent land")
