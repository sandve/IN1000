land = input("Velg land i nordre Skandinavia: ")
if land == "Norge":
    print("Oslo")
if land == "Sverige":
    print("Stockholm")
