pris = 5
print("Et eple koster:")
print(pris*1)
print("To epler koster:")
print(pris*2)
print("Tre epler koster:")
print(pris*3)
