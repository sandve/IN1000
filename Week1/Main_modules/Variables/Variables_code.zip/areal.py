lengde = 4
bredde = 5
areal = lengde * bredde
print(areal)
